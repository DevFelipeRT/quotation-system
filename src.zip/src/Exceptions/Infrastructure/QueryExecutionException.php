<?php

declare(strict_types=1);

namespace App\Exceptions\Infrastructure;

use Throwable;

/**
 * Exception thrown when a SQL query fails to execute using PDO.
 *
 * Used to signal that a database operation could not be completed,
 * either due to invalid SQL, parameter mismatch, or driver error.
 */
final class QueryExecutionException extends InfrastructureException
{
    /**
     * @param string         $message   Optional error message.
     * @param int            $code      Optional error code.
     * @param array          $context   Diagnostic context (SQL, parameters, bindings).
     * @param Throwable|null $previous  Optional PDOException or underlying cause.
     */
    public function __construct(
        string $message = 'Database query execution failed.',
        int $code = 0,
        array $context = [],
        ?Throwable $previous = null
    ) {
        parent::__construct($message, $code, $context, $previous);
    }
}
