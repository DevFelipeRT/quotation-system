<?php

declare(strict_types=1);

namespace App\Exceptions\Infrastructure;

use Throwable;

/**
 * Exception thrown when a database connection attempt fails.
 *
 * Typical causes include misconfigured DSN, invalid credentials,
 * network issues, or unhandled PDO-level errors.
 */
final class DatabaseConnectionException extends InfrastructureException
{
    /**
     * @param string         $message   Optional error message.
     * @param int            $code      Optional error code.
     * @param array          $context   Additional diagnostic context (host, driver, etc).
     * @param Throwable|null $previous  Optional chained exception (e.g. PDOException).
     */
    public function __construct(
        string $message = 'Unable to connect to the database.',
        int $code = 0,
        array $context = [],
        ?Throwable $previous = null
    ) {
        parent::__construct($message, $code, $context, $previous);
    }
}
