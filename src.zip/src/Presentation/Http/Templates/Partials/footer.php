</div>
<footer>
        <div class="footer-container">
            <!-- Informações de contato -->
            <div class="contact-info">
                <p>Email: contato@exemplo.com</p>
                <p>Telefone: (11) 1234-5678</p>
            </div>

            <!-- Direitos autorais -->
            <div class="copyright">
                <p>&copy; 2025 Sua Empresa. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>
    <script src="<?= $baseUrl ?>assets/js/main.js" type="module"></script>
</body>
</html>