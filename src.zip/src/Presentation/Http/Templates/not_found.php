<div style="display: flex; flex-direction: column; justify-content: center; height: 100%; text-align: center;">

    <h1 style="font-size: 3rem; color:rgb(139, 139, 139); margin-bottom: 10px;">404</h1>
    <p style="font-size: 1.5rem; color: #333;">Página não encontrada</p>
  

</div>